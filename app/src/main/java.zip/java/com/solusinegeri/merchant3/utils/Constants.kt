package com.solusinegeri.merchant3.utils

object Constants {
    const val BASE_URL = "https://api.solusinegeri.com/"
    const val APP_NAME = "Solusi Negeri Merchant"
}
