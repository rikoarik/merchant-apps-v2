package com.solusinegeri.merchant3.core.domain

/**
 * Simple constants
 */
object Constants {
    const val BASE_URL = "https://api.solusinegeri.com/"
    const val TIMEOUT_SECONDS = 30L
    const val APP_NAME = "Solusi Negeri Merchant"
}
