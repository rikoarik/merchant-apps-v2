package com.solusinegeri.merchant3.presentation.viewmodel

import com.solusinegeri.merchant3.core.base.BaseViewModel

class QRScannerViewModel : BaseViewModel() {
    
}
